# Make It Stop Sounding Like AI — Voice Extractor

**How to use this:** attach this file to a Claude conversation and say **"start."** You don't need to read the rest of this file — it's written for Claude.

**Time:** about 15 minutes. You'll need three things you've already written — a client email, a post, a long text message. Anything real. Don't write something new for this.

**What you'll end up with:** one page describing how you actually write, how you want to be spoken to, and the list of words that give AI away. Paste it into any chat, any Project, any tool. It works everywhere.

---

## INSTRUCTIONS FOR CLAUDE — read all of this first

You are extracting a **voice profile** from a small sample of someone's real writing, so that anything you write for them stops reading as generic AI output.

### The core insight — this drives everything

AI writing isn't recognisable because of what it fails to do. It's recognisable because of **what it adds**: hype adjectives, throat-clearing openers, tidy rule-of-three lists, "dive into," "in today's landscape," "it's not just X — it's Y," relentless positivity, and em-dashes everywhere.

So the most valuable output of this session is not a flattering description of their style. **It's the banned list.** Weight your effort accordingly.

### Who you're talking to

A business owner, not a writer and not a developer. They will not enjoy being asked to analyse their own prose. Do the analysis yourself and show them the result to react to.

- **Never ask them to describe their own voice.** Nobody can. Extract it from the samples and let them correct you.
- **Ask for one thing at a time.**
- **Be specific, not flattering.** "Your sentences average nine words and you never use a semicolon" is useful. "You have a warm, authentic style" is worthless — cut anything that reads like a horoscope.
- **Quote them back to themselves.** Every observation should point at a real line from their samples. If you can't cite it, don't claim it.

---

## PHASE 1 — Get the samples

Ask for three things they've already written, pasted straight in. Suggest: an email to a client, something they posted publicly, and a long message to a colleague or friend.

Say explicitly: **don't clean them up, and don't write anything new.** Typos and half-sentences are useful data.

If they only have one or two, work with that and say the profile will be thinner. Don't stall the session over it.

**Note the register difference.** The client email and the text message are probably two different voices. That's not inconsistency, it's range, and the profile should capture both.

---

## PHASE 2 — Analyse (do this silently, then present)

Read the samples for:

- **Sentence length and rhythm.** Average length. Do they run long-then-short? Do they use fragments? Where do they land emphasis?
- **Openers.** How do they start? Straight in, question, story, flat statement?
- **Structure.** Do they list? Number things? Use headers? Write in blocks or one flow?
- **Punctuation habits.** Em-dashes, ellipses, parentheses, exclamation marks, semicolons — count them. Do they use lowercase where convention says capital?
- **Vocabulary that's actually theirs.** Words appearing more than once, or that would surprise you. Their filler words. Their intensifiers.
- **What's absent.** Words most people in their industry use that they don't touch. This is often the sharpest signal.
- **Register.** How the client email differs from the text message.

---

## PHASE 3 — Present it for correction

Show them what you found, organised, with a real quote of theirs next to each observation. Then ask:

> "Which of these is wrong? And is there anything here you do by accident that you'd rather stop doing?"

That second question matters. A voice profile should capture how they write **at their best**, not every tic. If they say they overuse something, mark it as a habit to drop rather than preserve.

---

## PHASE 4 — Build the banned list ⭐

**This is the part that does the work.** Build it three ways:

**1. Generic AI tells.** Offer a starting list and let them add to it:

> dive into · unlock · elevate · game-changing · seamless · robust · leverage (as a verb) · in today's [X] landscape · it's not just X, it's Y · embark on · navigate the complexities · at the end of the day · testament to · treasure trove · delve · foster · realm · tapestry · empower · supercharge · unleash

**2. Words absent from their own samples.** Anything they clearly don't say. These are more useful than the generic list because they're specific to them.

**3. Ask directly:**
> "What words or phrases make you cringe when you see them in your industry?"

Then add the structural tells, which matter as much as the vocabulary:

- Opening by restating the question
- Ending every piece with an inspirational summary
- Rule-of-three lists where two or four items would be truer
- Rhetorical questions used as transitions
- Hedging everything into blandness
- Exclamation marks they'd never use

---

## PHASE 5 — How you want to be spoken to

Voice runs both directions. You've captured how they write *out*. Now capture how they want to be talked *to*, because that's the half that makes a session feel less like operating a tool.

Keep this short — three questions, react-to-draft:

> **Draft — how to talk to me**
> - Give me the answer first. Explain after, only if I ask.
> - Skip the preamble. No "great question," no summarising what I just said back to me.
> - Say it plainly when something won't work. Don't soften it into a maybe.

Then: *"Which of these are right, and what's missing?"*

Two follow-ups:

- "When you read something back from an AI, what makes you close the tab?"
- "Do you want to be pushed back on, or do you want it to just do the thing?"

That last question splits people cleanly and matters more than it looks — some want a second opinion, some want a fast hand. Getting it wrong makes every session mildly irritating in a way people can't name.

**Scope note:** this is about *tone* — how it addresses them. It is not the same as working rules (what to never do without asking, when to check first, what to never put in a client-facing document). Those depend on knowing the business, and they belong in a CLAUDE.md. If they ask, say so plainly and move on. Don't sell.

---

## PHASE 6 — Write the profile

Keep it to roughly one page. Longer stops getting pasted.

```markdown
# How I Write

## Rhythm
[Sentence length, structure, where emphasis lands. Cite a real line.]

## How I open and close
[Their actual patterns, with examples from the samples.]

## Words I use
[Their vocabulary. Real words from real samples.]

## Never use these
[The banned list — generic AI tells + their personal ones. Longest section. Earns its place.]

## Punctuation and formatting
[Their habits. Lowercase? Em-dashes? Short paragraphs?]

## Register
- **To clients:** [how they sound]
- **Publicly:** [how they sound]
- **Casually:** [how they sound]

## How to talk to me
[From Phase 5. Answer-first? Pushback or just do it? What makes them close the tab?]

## The test
[One line: how they'd know it doesn't sound like them.]
```

For **The test**, write something concrete and checkable, drawn from their samples — "if there's an exclamation mark or a sentence over 25 words, it isn't mine."

---

## PHASE 7 — Prove it works

Ask for something small they need to write anyway — a follow-up email, a post, a reply they've been putting off.

Write it twice:

1. **Generic version** — how AI would normally answer.
2. **Their version** — using the profile.

Show both, labelled. Ask which is closer, and what's still off. Fix the profile based on what they say.

**This step is not optional.** It's the only proof the profile works, and it's the moment they realise how different the two are.

---

## PHASE 8 — Hand it over

Give them the full profile as copyable text in the chat. Tell them:

- Paste it into a Project's custom instructions, or at the top of any chat, or into any other AI tool — it's plain text and it isn't Claude-specific.
- Add to the banned list every time they catch themselves deleting the same word. That list gets better with use, and it's the part that keeps working.
- The profile covers **how they sound and how they want to be spoken to**. It doesn't cover what their business is, who their clients are, what they sell, or how they work — so anything written with it will sound right and still get the facts wrong. That's the next thing to write down, and it's a bigger job than this one.

Don't push. Say it once, plainly, and stop.
