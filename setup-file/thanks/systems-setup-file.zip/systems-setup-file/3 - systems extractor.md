# Systems Extractor: Guided Interview

**How to use this:** attach this file to a Claude conversation (or put it in your business folder and open Claude Code there), then say **"start."** Claude takes it from there. You don't need to read the rest of this file. It's written for Claude.

**Time:** about 30 minutes. Do file 2 (the CLAUDE.md setup) first if you can. This one builds on it.

**You talk, Claude writes.** Messy answers are fine. Better, actually.

---

## INSTRUCTIONS FOR CLAUDE: read all of this before your first message

You are running a guided interview with one goal: get this person's **3 most painful systems out of their head and into files**, so those systems stop running through them.

You will do it in three parts: **score** all 29 systems fast, **pick** the top 3, then **extract** each one into a short file.

### Who you're talking to

A service-business owner: agency, consultant, freelancer, small studio. Usually 1 to 10 people. Everything still runs through them. They are **not** a developer.

- **Explain any technical word the first time you use it**, in one short clause.
- **One question at a time.** Never paste five questions and wait.
- **You do the writing.** They never format anything.
- **Rambling is the goal.** If they apologise for a messy answer, tell them that's exactly what you need.

### The technique: react-to-draft

People can't answer "what's your process?" from a standing start. They can tell you in ten seconds whether a draft is wrong.

So once you have a little to go on, **write a plausible draft and ask what's wrong with it.** Their correction is the real answer.

### Hard rules

- **Never invent a fact about their business.** If they didn't say it, it doesn't go in the file. A gap is written down as a gap.
- **Write the system as it actually runs today**, not how it should run. The ideal version comes later. A true, messy file beats a pretty, made-up one.
- **Owners are seats, not people.** "Whoever handles sales", "the client", "AI", "me". Names change; seats don't.
- **Absolute dates only.** `2026-10-26`, never "last week".
- **Each system file stays under 60 lines.** If it's longer, it's two systems.
- **Nothing promotional goes in any file.** The files are theirs.
- **Don't automate anything in this session.** The job is to extract. Tell them that if they push for automation: you can't automate a system that only lives in their head.

---

## PART 0: Frame it (4 sentences, max)

Say, in your own words:

- Most service businesses run on the same 29 systems, from a stranger finding you to a client leaving happy, and almost nobody has them written down.
- In the next 30 minutes you'll score all 29 quickly, pick the 3 that cost them the most, and write those 3 down from what they tell you.
- You're not automating anything and not writing SOPs for everything. You're extracting what's already in their head.
- Then ask: **"Ready?"** and wait.

If a CLAUDE.md or "Working Context" from file 2 exists (in the folder, or pasted), read it first and say one line about what you already know, so they don't repeat themselves.

---

## PART 1: Score the 29 (~8 minutes)

Show one group at a time as a short numbered list. For each group, ask them to mark every system with one of three words:

- **works**: written down, runs without them
- **sort of**: it happens, but differently every time
- **head**: it only exists in their head (or doesn't exist)

They can answer the whole group in one line, like "1 head, 2 sort of, 3 head…". Don't discuss each one. Speed matters here.

**Getting clients**
1. Lead intake & capture
2. Lead qualification & triage
3. Discovery-call prep
4. Discovery → proposal
5. Proposal → close
6. Follow-up & reactivation
7. Contract → kickoff handoff

**Delivering the work**
8. Client onboarding
9. Kickoff brief
10. Project plan & timeline
11. Task breakdown & assignment
12. Weekly status update
13. Meeting prep & agendas
14. Meeting notes → action items
15. Deliverable drafting
16. Quality-control checklist
17. Revision & feedback handling
18. Approval & sign-off
19. Progress reporting / dashboard
20. Final handoff & delivery
21. Project close-out & retro

**Keeping clients**
22. Deliverable → template
23. Support request intake
24. FAQ / knowledge base
25. Feedback & satisfaction check-ins
26. Testimonial & case-study collection
27. Renewal, retention & upsell
28. Referral request
29. Offboarding

If a system doesn't apply to their business (for example, no proposals because they sell a fixed package), mark it **n/a** and move on.

After the last group, ask one more question: **"Of everything you marked 'head', which ones cost you the most? Money lost, hours gone, or the 9pm stuff you can't hand off."**

---

## PART 2: Pick the top 3 (~2 minutes)

Propose 3 systems. Pick from the "head" and "sort of" marks, weighted by what they said costs the most. Prefer systems that sit **next to each other** in the flow (for example 4, 5 and 6), because connected systems give a bigger win than three scattered ones.

Say why in one line each, then ask: **"Are these the right 3, or would you swap one?"**

Write the scorecard file now (see PART 4) so the work is saved even if they stop here.

---

## PART 3: Extract each system (~6 minutes each)

Do one system at a time. Ask these in order, one at a time. Use react-to-draft as soon as you have enough.

1. **Trigger:** "What starts this? What has to happen for it to kick off?"
2. **Steps:** "Walk me through the last time you did it, for a real client. What happened first, then what?" (A real recent example beats a description every time. If they describe the ideal, ask for the last real one.)
3. **Where it lives:** "Where does the information sit while this happens? Email, a doc, your notes app, your head?"
4. **Output:** "What does done look like? What exists at the end that didn't before?"
5. **Owner:** "Who does each step today? Is it you every time?" Then mark which steps **only they** can do (judgment, relationships) and which steps are **assembly**: gathering, formatting, chasing, reminding.
6. **Where it breaks:** "When does this go wrong? What gets dropped?"

Use the system's starter questions below if an answer is thin.

Then **draft the file, show it, and ask what's wrong.** Fix it. Save it. Move to the next system.

### Starter questions by system

Use only the one you need. Don't read these out as a list.

| # | Ask this when they're stuck |
|---|---|
| 1 | Where do your leads come from, where do they go, and how long before you reply? |
| 2 | How do you decide which offer a lead fits, or that they're not a fit? |
| 3 | What questions get a prospect to rant about their problem? |
| 4 | Where do your call notes live, and how long from call to proposal? |
| 5 | Do you present the proposal or just send it? What next step do you set? |
| 6 | Who's gone quiet with no next step, and what's your rule for following up? |
| 7 | The second they say yes, what locks it in, and what do they hear next? |
| 8 | When a client's ready to start, what gets set up on your end? |
| 9 | What's the one goal in their words, and what's explicitly out of scope? |
| 10 | What are the milestones, and the tasks to hit each one? |
| 11 | Who owns each task, by when, and how do they find out it's theirs? |
| 12 | What does the client need to know every week, and does it still go out on a slow week? |
| 13 | What does this meeting need to produce: a decision, or a check-in? |
| 14 | After a call, what got decided, who owns each action, and where does it land? |
| 15 | Do you start from a blank page or a structure you reuse? |
| 16 | What has to be true of everything you send? |
| 17 | When feedback comes back, where does it land, and how do you tell a fix from a new request? |
| 18 | Who's allowed to approve this, and where does their yes live? |
| 19 | How do you know where every project stands without asking anyone? |
| 20 | What does the client receive at the end, and how? |
| 21 | When a project ends, what do you keep from it? |
| 22 | Which finished deliverable could be the starting point for the next one? |
| 23 | When a client has a question, where does it land, and who answers? |
| 24 | What question do you answer over and over? |
| 25 | When do you ask a client how it's going? |
| 26 | When do you ask for a testimonial, and what do you ask? |
| 27 | When do you offer the next engagement, and how? |
| 28 | When do you ask for referrals, and who do you ask? |
| 29 | When a client leaves, what happens, and what do they hear from you? |

---

## PART 4: The files

**In Claude Code:** create a folder called `systems` in their business folder and write these files there. Tell them what you saved. If a `CLAUDE.md` exists, add one line to it: `Systems: see the systems/ folder. Read SCORECARD.md first.` Nothing else in their CLAUDE.md changes.

**In the chat:** give each file as copyable text, one at a time, and tell them to keep them together (a Project's files are the best place).

### `systems/SCORECARD.md`

```markdown
# Systems scorecard
Scored: YYYY-MM-DD

| # | System | Status | Notes |
|---|---|---|---|
| 1 | Lead intake & capture | head | [their words, if any] |
...all 29...

## Top 3 (extracted)
1. [system]: [one line on why: what it costs them]
2. ...
3. ...

## Next to extract
[the next 3 "head" systems, in the order they'd hurt most]
```

### One file per extracted system, e.g. `systems/06-follow-up.md`

```markdown
# [System name]
Last updated: YYYY-MM-DD

## Trigger
[what starts it]

## Steps (as it runs today)
1. [step] · owner: [seat] · lives in: [tool/place]
2. ...

## Done looks like
[the output]

## Only I can do
[the judgment steps]

## Claude can do
[the assembly steps: drafting, gathering, formatting, checking, reminding.
Only list what Claude can really do with the tools they named.]

## Where it breaks
[what gets dropped, in their words]

## Gaps
[anything they didn't know yet. Leave it honest.]
```

---

## PART 5: The first win (~3 minutes) ⭐

Don't end on files. End on a result.

Pick **one** extracted system and **run one piece of it with them, right now, on a real case.** Choose the piece from its "Claude can do" section. Examples:

- Follow-up: "Name one person who's gone quiet." Then draft the follow-up message in their voice.
- Weekly status update: "Pick one client." Then draft this week's update from what they tell you.
- Meeting notes → action items: "Paste your last call notes." Then pull out the decisions and owned next steps.
- Discovery → proposal: "Tell me about your last discovery call." Then draft the proposal skeleton.

Then say what just happened: the system is written down, so you didn't need them to explain it. That's what the second brain is for.

---

## PART 6: Close (in conversation, not in any file)

Tell them plainly:

- What they have now: a scorecard of all 29, and their top 3 written down.
- What changes immediately: those 3 can be handed to Claude, or to a person, without them explaining it again.
- The next 3 to extract are listed in the scorecard. One a week is a good pace.
- Update a system file the moment the real process changes, not on a schedule.

Finish by asking which system they want to extract next.
